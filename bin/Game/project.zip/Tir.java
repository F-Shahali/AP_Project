package Game;


import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Tir {
	int Speed, power, Num = 1, PowerUp, powerOfarrow, degree, ActingPower, type, MaximumHeat;
	BufferedImage tir;
	int x, y, Distance = 0, XNow, YNow;
	double IncreasingHeat;
	boolean drawing = true;
	int[] InFile;
	static Tir ti;
	
	public Tir(int type){
		this.type = type;
		ti = this;
		initialize();
		
	}
	public void initialize() {
		
//		try {
//			tir = ImageIO.read(new File("file/Tir/" + type + "-" + 90 + ".png"));
//		} catch (IOException e) {}
		if(type == 1) {
			this.Speed = 200;
			this.power = 1;
			this.IncreasingHeat = 5;
			this.MaximumHeat = 100;
		}
		if(type == 2) {
			this.Speed = 150;
			this.power = 2;
			this.IncreasingHeat = 6;
			this.MaximumHeat = 100;
		}
		if(type == 3) {
			this.Speed = 100;
			this.power = 3;
			this.IncreasingHeat = 4;
			this.MaximumHeat = 100;
		}
		if(Game.game.ActingPower == 1 || Game.game.ActingPower == 2 || Game.game.ActingPower == 3) {
			Game.game.NumberOfArrow = Game.game.ActingPower+1;
		}
		if(Game.game.ActingPower > 3) {
			Game.game.NumberOfArrow = 4;
			ActingPower = this.power + (Game.game.ActingPower-3)*(25/100)*this.power;
		}
//		try {
//			InFile = new int[8];
//			String lines;
//			int i =0;
//			BufferedReader bw = new BufferedReader(new FileReader("file/" + Game.game.name + ".data"));
//			while((lines = bw.readLine()) != null) {
//				InFile[i] = Integer.valueOf(lines);
//				i++;
//			}
//			bw.close();
//			powerOfarrow = InFile[3];
//			KindOfarrow = InFile[4];
//			
//			
//		} catch (Exception e) {}
	}
	public Tir() {
		
	}

}
